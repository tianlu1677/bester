server "bester-server", user: "deploy", roles: %w{app}, my_property: :my_value
