# README

# 使用步骤
1. 复制代码
2. 修改 application.rb, database.yml
3. 修改dockerfile 中的名字