class ApplicationController < ActionController::Base
  include Clearance::Controller
end
