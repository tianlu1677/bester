class Admin::HomeController < Admin::ApplicationController

  def index

  end
end