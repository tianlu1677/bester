# frozen_string_literal: true

class Clearance::BaseController < ApplicationController
  layout 'login'
end
