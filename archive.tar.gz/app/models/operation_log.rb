class OperationLog < ApplicationRecord
end
